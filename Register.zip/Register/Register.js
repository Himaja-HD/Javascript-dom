const studentRegisterBody = document.getElementById("studentRegisterBody");
const addStudentButton = document.getElementById("addStudentButton");
const editStudentButton = document.getElementById("editStudentButton");

let studentList = getStudentListFromLocalStorage();
let studentsCount = studentList.length;
let currentEditingStudentId = null;

// Get student list from localStorage
function getStudentListFromLocalStorage() {
  const storedData = localStorage.getItem("studentList");
  return storedData ? JSON.parse(storedData) : [];
}

// Update localStorage with current student list
function updateLocalStorage() {
  localStorage.setItem("studentList", JSON.stringify(studentList));
}

// Add new student
function onAddStudent() {
  const name = document.getElementById("studentNameInput").value.trim();
  const studentID = document.getElementById("studentIDInput").value.trim();
  const email = document.getElementById("studentEmailInput").value.trim();
  const contact = document.getElementById("studentContactInput").value.trim();

  if (!validateInputs(name, studentID, email, contact)) return;

  studentsCount++;
  const newStudent = { name, studentID, email, contact, uniqueNo: studentsCount };

  studentList.push(newStudent);
  createStudentRow(newStudent);
  clearFields();
  updateLocalStorage();
}

// Validate input fields
function validateInputs(name, studentID, email, contact) {
  if (!name || !/^[a-zA-Z\s]+$/.test(name)) {
    alert("Please enter a valid name!");
    return false;
  }
  if (!studentID) {
    alert("Student ID cannot be empty!");
    return false;
  }
  if (!email || !/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/.test(email)) {
    alert("Please enter a valid email!");
    return false;
  }
  if (!contact || isNaN(contact)) {
    alert("Contact must be numeric!");
    return false;
  }
  return true;
}

// Edit student
function onEditStudent(studentId) {
  currentEditingStudentId = studentId;
  const student = studentList.find(student => `student${student.uniqueNo}` === studentId);

  if (student) {
    document.getElementById("studentNameInput").value = student.name;
    document.getElementById("studentIDInput").value = student.studentID;
    document.getElementById("studentEmailInput").value = student.email;
    document.getElementById("studentContactInput").value = student.contact;

    addStudentButton.style.display = "none";
    editStudentButton.style.display = "inline-block";
  }
}

// Update student record
function onUpdateStudent() {
  const name = document.getElementById("studentNameInput").value.trim();
  const studentID = document.getElementById("studentIDInput").value.trim();
  const email = document.getElementById("studentEmailInput").value.trim();
  const contact = document.getElementById("studentContactInput").value.trim();

  if (!validateInputs(name, studentID, email, contact)) return;

  const studentIndex = studentList.findIndex(student => `student${student.uniqueNo}` === currentEditingStudentId);

  if (studentIndex !== -1) {
    studentList[studentIndex] = { ...studentList[studentIndex], name, studentID, email, contact };

    const studentRow = document.getElementById(currentEditingStudentId);
    studentRow.querySelector(".name-cell").textContent = name;
    studentRow.querySelector(".id-cell").textContent = studentID;
    studentRow.querySelector(".email-cell").textContent = email;
    studentRow.querySelector(".contact-cell").textContent = contact;

    clearFields();
    currentEditingStudentId = null;
    addStudentButton.style.display = "inline-block";
    editStudentButton.style.display = "none";
    updateLocalStorage();
  }
}

// Delete student record
function onDeleteStudent(studentId) {
  const studentRow = document.getElementById(studentId);
  studentRegisterBody.removeChild(studentRow);
  studentList = studentList.filter(student => `student${student.uniqueNo}` !== studentId);
  updateLocalStorage();
}

// Clear input fields
function clearFields() {
  document.getElementById("studentNameInput").value = "";
  document.getElementById("studentIDInput").value = "";
  document.getElementById("studentEmailInput").value = "";
  document.getElementById("studentContactInput").value = "";
}

// Create a table row for student
function createStudentRow(student) {
  const studentId = `student${student.uniqueNo}`;

  const row = document.createElement("tr");
  row.id = studentId;
  row.innerHTML = `
    <td class="name-cell">${student.name}</td>
    <td class="id-cell">${student.studentID}</td>
    <td class="email-cell">${student.email}</td>
    <td class="contact-cell">${student.contact}</td>
    <td>
      <button class="edit-button">Edit</button>
      <button class="delete-button">Delete</button>
    </td>
  `;

  row.querySelector(".edit-button").onclick = () => onEditStudent(studentId);
  row.querySelector(".delete-button").onclick = () => onDeleteStudent(studentId);

  studentRegisterBody.appendChild(row);
}

// Initialize student records on page load
studentList.forEach(createStudentRow);

// Event listeners for adding and updating students
addStudentButton.onclick = onAddStudent;
editStudentButton.onclick = onUpdateStudent;
